/**
 * @author 노민에르덴
 * @version 2022.11.29
 */

/**
 * 해당 클래스의 포함되어 있는 패키지
 */
package kr.ac.kookmin.cs;

public class PPoint {
    /**
     * 필드
     */
    int xA;
    int yA;

    /**
     * public 생성자 
     * @param x
     * @param y
     */
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };

    /**
     * 이 메소드 파라미터 x의 값을 리턴합니다.
     * @return x
     */
    public int getX() {
        return xA;
    }

    /**
     * 이 메소드 파라미터 y의 값을 리턴합니다.
     * @return y
     */
    public int getY() {
        return yA;
    }
}
