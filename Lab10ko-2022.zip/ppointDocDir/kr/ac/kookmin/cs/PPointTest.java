/**
 * @author 노민 에르덴
 * @version 2022.11.29
 */

/**
 * 해당 클래스의 포함되어 있는 패키지
 */
package kr.ac.kookmin.cs;

/**
 * import 
 */
import kr.ac.kookmin.cs.*;

/**
 * Public class named PPoinTest
 * 
 */
class PPointTest {
	/**
	 * Main method 
	 * @param 
	 */
    public static void main(String args[]) {
        PPoint aObj = new PPoint(10, 20);
        System.out.println("aObj(x, y) = " + aObj.getX() + ", "+ aObj.getY());
    }
}
